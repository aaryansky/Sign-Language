# yolov5-demo > 2024-12-30 4:10pm
https://universe.roboflow.com/aryan-workspace/yolov5-demo-3pmdp

Provided by a Roboflow user
License: CC BY 4.0

